function [ output_args ] = knn_boundry( features, labels )
%KNN_BOUNDRY Summary of this function goes here
%   Detailed explanation goes here

% generate random numbers
mat = rand(10000,2);
class = ones(1,10000);
k = 5;

[IDX,D] = knnsearch(features,mat,'K',k);

for row=1:length(IDX)
    sum = 0;
    for col=1:k
        sum = sum + labels(IDX(row,col));
    end
    
    if sum<0
        class(row) = -1;
    elseif sum>0
        class(row) = 1;
    else
        rnd = randi([0 1],1);
        if rnd == 0
            rnd = -1;
        end
        class(row) = rnd;
    end 
end
class = class';

% gscatter(features(:,1),features(:,2),labels);
gscatter(mat(:,1),mat(:,2),class,'br','ds');
end

