train_label=importLabel('car_train.data');
test_label=importLabel('car_test.data');
valid_label=importLabel('car_valid.data');
valid_data=importFeatures('car_valid.data');
test_data=importFeatures('car_test.data');
train_data=importFeatures('car_train.data');

new_train_label = double(categorical(train_label));
new_train_data = dummyvar(categorical(train_data(:,1)));
for i = 2:6
    new_train_data = horzcat(new_train_data, dummyvar(categorical(train_data(:,i))));
end

new_test_label = double(categorical(test_label));
new_test_data = dummyvar(categorical(test_data(:,1)));
for i = 2:6
    new_test_data = horzcat(new_test_data, dummyvar(categorical(test_data(:,i))));
end

new_valid_label = double(categorical(valid_label));
new_valid_data = dummyvar(categorical(valid_data(:,1)));
for i = 2:6
    new_valid_data = horzcat(new_valid_data, dummyvar(categorical(valid_data(:,i))));
end

clearvars i;