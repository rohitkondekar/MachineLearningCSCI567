function [  ] = CSCI567_hw5()

path = pwd;
addpath(genpath(strcat(path,'/myFiles')));
addpath(genpath(strcat(path,'/hw5_data')));
addpath(genpath(strcat(path,'/libsvm-3.20')));

load('face_data.mat');
load('hmm_data.mat');



%Part1 : PCA Implemented in function pca_fun.m

%Part2 : Obtain Eigenfaces

imageMat = reshape(image{1},1,2500);
for i=2:length(image)
    imageMat = [imageMat;reshape(image{i},1,2500)];
end

eigenVectors = pca_fun(imageMat,5);

figure(1); clf; set(gcf, 'Name', 'EigenFaces');
for i=1:5
    subplot(2,3,i);
    imshow(reshape(eigenVectors(:,i),50,50),[]);
    title(num2str(i));
end
drawnow;

%Part3 : Project each image into eigenspace

disp('Executing Linear SVM');
disp(' ');
%Linear SVM
d = [20, 50, 100, 200];
C = [4^-6,4^-5,4^-4,4^-3,4^-2,4^-1,1,4,4^2];


for k=1:length(d)
    eigenVectors = pca_fun(imageMat,d(k));
    lowerMat = imageMat*eigenVectors;
    
    tsum = 0;
    for j=unique(subsetID)
        
        test_data = double(lowerMat(subsetID==j,:));
        test_label = personID(subsetID==j)';
        
        train_data = double(lowerMat(subsetID~=j,:));
        train_label = personID(subsetID~=j)';
        
        
        validation_maxAccuracy = 0;
        validation_maxC = 0;
        
        %Getting Optimal Parameter - Using Leave One out
        for c = C
           validation_tsum = 0;
           for t =  unique(subsetID(subsetID~=j))    
               new_train_data = double(lowerMat(subsetID(subsetID~=j)~=t,:));
               new_train_label = personID(subsetID(subsetID~=j)~=t)';
               
               validation_data = double(lowerMat(subsetID(subsetID~=j)==t,:));
               validation_label = personID(subsetID(subsetID~=j)==t)';
               
               options = ['-q -s 0 -t 0 -c',' ',num2str(c)];
               model = svmtrain(new_train_label,new_train_data,options);
               result = svmpredict(validation_label,validation_data,model,'-q');
               
               validation_accuracy = sum(result==validation_label)/length(validation_label);
               validation_tsum = validation_tsum + validation_accuracy;               
           end
           
            validation_tsum = 100*validation_tsum/4;
            if validation_tsum>validation_maxAccuracy
                validation_maxAccuracy = validation_tsum;
                validation_maxC = c;
            end
        end
        
        disp(strcat('Validation Linear SVM : Test Subset = ', num2str(j),' d = ',num2str(d(k)),' C = ',num2str(validation_maxC),' Avg Validation Accuracy = ',num2str(validation_maxAccuracy)));
       
        options = ['-q -s 0 -t 0 -c',' ',num2str(validation_maxC)];
        model = svmtrain(train_label,train_data,options);
        result = svmpredict(test_label,test_data,model,'-q');
        
        test_Accuracy = sum(result==test_label)/length(test_label);
        tsum = tsum + test_Accuracy;   
    end
    
    tsum = 100*tsum/5;
    disp(strcat('Test Linear SVM : d = ',num2str(d(k)),' Avg Test Accuracy = ',num2str(tsum)));
end
    
    
    

disp('Executing RBF Kernel SVM');
disp(' ');

% %RBF SVM
C = [4^-3,4^-2,4^-1,1,4,4^2,4^3,4^4,4^5,4^6,4^7];
gamma = [4^-7,4^-6,4^-5,4^-4,4^-3,4^-2];
d = [20, 50, 100, 200];

for k = 1:length(d)
    eigenVectors = pca_fun(imageMat,d(k));
    lowerMat = imageMat*eigenVectors;
    tsum = 0;
    
    for j=unique(subsetID)
        
        test_data = double(lowerMat(subsetID==j,:));
        test_label = personID(subsetID==j)';
        
        train_data = double(lowerMat(subsetID~=j,:));
        train_label = personID(subsetID~=j)';
        
        
        validation_maxAccuracy = 0;
        validation_maxC = 0;
        validation_maxG = 0;
        
        for c = C
            for g = gamma
               validation_tsum = 0;
               for t =  unique(subsetID(subsetID~=j))    
                   new_train_data = double(lowerMat(subsetID(subsetID~=j)~=t,:));
                   new_train_label = personID(subsetID(subsetID~=j)~=t)';

                   validation_data = double(lowerMat(subsetID(subsetID~=j)==t,:));
                   validation_label = personID(subsetID(subsetID~=j)==t)';

                   options = ['-q -s 0 -t 2 -g',' ',num2str(g),' ','-c',' ',num2str(c)];
                   model = svmtrain(new_train_label,new_train_data,options);
                   result = svmpredict(validation_label,validation_data,model,'-q');

                   validation_accuracy = sum(result==validation_label)/length(validation_label);
                   validation_tsum = validation_tsum + validation_accuracy;               
               end
               
                validation_tsum = 100*validation_tsum/4;
                if validation_tsum>validation_maxAccuracy
                    validation_maxAccuracy = validation_tsum;
                    validation_maxC = c;
                    validation_maxG = g;
                end
               
            end
        end
        
        disp(strcat('Validation RBF SVM : Test Subset = ', num2str(j),' d = ',num2str(d(k)),' C = ',num2str(validation_maxC),' Gamma = ',num2str(validation_maxG),' Avg Validation Accuracy = ',num2str(validation_maxAccuracy)));
        options = ['-q -s 0 -t 2 -g',' ',num2str(validation_maxG),' ','-c',' ',num2str(validation_maxC)];
        model = svmtrain(train_label,train_data,options);
        result = svmpredict(test_label,test_data,model,'-q');
        test_Accuracy = sum(result==test_label)/length(test_label);
        tsum = tsum + test_Accuracy;   
    end
    
    tsum = 100*tsum/5;
    disp(strcat('Test RBF Kernel SVM : d = ',num2str(d(k)),' Avg Test Accuracy = ',num2str(tsum)));
end



%Question 5
disp('');
disp('HMM Question 5------------');

baumwelch(data,[0.7,0.3;0.3,0.7],[0.25,0.25,0.25,0.25;0.25,0.25,0.25,0.25],500);

disp('Executing hmmtrain 500 Iterations ------------');
[ESTTR, ESTEMIT]=hmmtrain(data,[0.7,0.3;0.3,0.7],[0.25,0.25,0.25,0.25;0.25,0.25,0.25,0.25],'MAXITERATIONS',500)



end
