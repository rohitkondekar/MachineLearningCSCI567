function [A_estimate, E_estimate] = baumwelch(data, A_guess, E_guess, N_iter)
%
% Train Hidden Markov Model using the Baum-Welch algorithm (expectation maximization)
% Input:
%  data: N*T matrix, N data samples of length T
%  A_guess: K*K matrix, where K is the number hidden states [initial guess for the transition matrix]
%  E_guess: K*E matrix, where E is the number of emissions [initial guess for the emission matrix]
%
% Output:
%  A_estimate: estimate for the transition matrix after N_iter iterations of expectation-maximization 
%  E_estimate: estimate for the emission matrix after N_iter iterations of expectation-maximization
%
% CSCI 576 2014 Fall, Homework 5


%Assumption of 2 hidden states
%M = 2;

T = size(data,2); %total Time
N = size(data,1); %Number of data samples

M = size(A_guess,1); %Number of hidden states
E = size(E_guess,2); %Numer of Emissions

b = E_guess;
a = A_guess;

pi = [0.5,0.5];


disp('Executing 500 Iterations ...... Please Wait');

%%
for itr=1:N_iter

    a_numerator = zeros(M,M);
    a_denominator = zeros(M,M);
    
    b_numerator = zeros(M,E);
    b_denominator = zeros(M,E);
    
    for n=1:N
        O = data(n,:);
                               
        %%
        %Computing Forward Probabilities
        alpha = zeros(M,T);
        scaling = zeros(1,T);
        for i=1:M
           alpha(i,1) = pi(i)*b(i,O(1));
           scaling(1) = scaling(1)+alpha(i,1);        
        end
        
        for i=1:M
           alpha(i,1) = alpha(i,1)/scaling(1);          
        end

                
        for t=2:T
            for j=1:M
                sum = 0;
                for i=1:M
                   sum = sum+alpha(i,t-1)*a(i,j); 
                end
                alpha(j,t) = sum*b(j,O(t));                
                scaling(t) = scaling(t)+alpha(j,t);
            end                     
            
            for j=1:M
                alpha(j,t) = alpha(j,t)/scaling(t);       
            end            
        end
                      
        %-------------------------------------------------
        
        
        
        %%
        %Computing Backward Probabilities
        beta = zeros(M,T);
        
        for i=1:M
           beta(i,T) = 1/scaling(T);
        end
        
        for t=T-1:-1:1
           for i=1:M
              sum = 0;
              for j=1:M
                 sum = sum + a(i,j)*b(j,O(t+1))*beta(j,t+1);                                
              end              
              beta(i,t) = sum/scaling(t);
           end
        end
        %-------------------------------------------------
        
        
        %%
        %computing aij        
        for i=1:M
            for j=1:M
                for t=1:T-1
                    a_numerator(i,j) = a_numerator(i,j)+alpha(i,t)*a(i,j)*b(j,O(t+1))*beta(j,t+1);
                    a_denominator(i,j) = a_denominator(i,j)+alpha(i,t)*beta(i,t)*scaling(t);
                end
            end
        end  

        
        for e=1:E
            for j=1:M
                for t=1:T
                    if O(t) ==  e
                        b_numerator(j,e) = b_numerator(j,e)+alpha(j,t)*beta(j,t)*scaling(t);
                    end            
                        b_denominator(j,e) = b_denominator(j,e)+alpha(j,t)*beta(j,t)*scaling(t);
                end
            end
        end                 
  
    end    
    
    %%
    for i=1:M
        for j=1:M
            a(i,j) = a_numerator(i,j)/a_denominator(i,j);
        end
    end
    
    for e=1:E
        for j=1:M
            b(j,e) = b_numerator(j,e)/b_denominator(j,e);
        end
    end
end
    disp(strcat('Completed 500 Iteration'));
    disp(a);
    disp(b);

end












